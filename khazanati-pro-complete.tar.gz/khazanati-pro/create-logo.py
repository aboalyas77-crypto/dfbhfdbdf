from PIL import Image, ImageDraw, ImageFont
import os

# Create a simple logo
width, height = 200, 200
image = Image.new('RGB', (width, height), color='#3B82F6')

# Draw circle
draw = ImageDraw.Draw(image)
draw.ellipse([10, 10, 190, 190], fill='#1E40AF', outline='#ffffff', width=3)

# Save logo
logo_path = '/home/ubuntu/khazanati-pro/client/public/logo.png'
os.makedirs(os.path.dirname(logo_path), exist_ok=True)
image.save(logo_path)
print(f"✅ تم إنشاء {logo_path}")

# Create favicon
favicon_path = '/home/ubuntu/khazanati-pro/client/public/favicon.ico'
image.save(favicon_path)
print(f"✅ تم إنشاء {favicon_path}")
