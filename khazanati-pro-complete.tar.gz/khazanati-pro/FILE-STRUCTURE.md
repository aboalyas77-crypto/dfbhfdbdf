# هيكل ملفات خزانتي برو

## 📁 الهيكل الكامل للمشروع

```
khazanati-pro/
├── 📂 client/                          # واجهة المستخدم (Frontend)
│   ├── 📂 public/                      # الملفات الثابتة والأصول
│   │   ├── logo.svg                    # شعار التطبيق
│   │   └── favicon.ico                 # أيقونة المتصفح
│   ├── 📂 src/                         # كود React
│   │   ├── 📂 _core/                   # الأدوات الأساسية
│   │   │   └── hooks/
│   │   │       └── useAuth.ts          # hook للمصادقة
│   │   ├── 📂 components/              # مكونات React
│   │   │   ├── DashboardLayout.tsx     # تخطيط لوحة التحكم
│   │   │   ├── AIChatBox.tsx           # مكون المحادثة
│   │   │   ├── Map.tsx                 # مكون الخريطة
│   │   │   ├── ErrorBoundary.tsx       # معالج الأخطاء
│   │   │   └── ui/                     # مكونات shadcn/ui
│   │   │       ├── button.tsx
│   │   │       ├── card.tsx
│   │   │       ├── input.tsx
│   │   │       ├── textarea.tsx
│   │   │       ├── dialog.tsx
│   │   │       ├── tabs.tsx
│   │   │       └── ... (50+ مكون)
│   │   ├── 📂 pages/                   # صفحات التطبيق
│   │   │   ├── Home.tsx                # صفحة الهبوط
│   │   │   ├── Dashboard.tsx           # لوحة التحكم
│   │   │   ├── Settings.tsx            # الإعدادات
│   │   │   ├── Pricing.tsx             # خطط الأسعار
│   │   │   ├── Chat.tsx                # محادثة AI
│   │   │   ├── ImageGeneration.tsx     # توليد الصور
│   │   │   ├── TextAnalysis.tsx        # تحليل النصوص
│   │   │   ├── Files.tsx               # إدارة الملفات
│   │   │   └── NotFound.tsx            # صفحة 404
│   │   ├── 📂 contexts/                # React Contexts
│   │   │   └── ThemeContext.tsx        # إدارة المظهر
│   │   ├── 📂 hooks/                   # Custom Hooks
│   │   │   ├── useComposition.ts
│   │   │   ├── useMobile.tsx
│   │   │   └── usePersistFn.ts
│   │   ├── 📂 lib/                     # مكتبات مساعدة
│   │   │   ├── trpc.ts                 # عميل tRPC
│   │   │   └── utils.ts                # دوال مساعدة
│   │   ├── App.tsx                     # المكون الرئيسي
│   │   ├── main.tsx                    # نقطة البداية
│   │   ├── const.ts                    # الثوابت
│   │   └── index.css                   # الأنماط العامة
│   ├── index.html                      # ملف HTML الرئيسي
│   └── vite.config.ts                  # إعدادات Vite
│
├── 📂 server/                          # الخادم (Backend)
│   ├── 📂 _core/                       # الأدوات الأساسية
│   │   ├── index.ts                    # نقطة بداية الخادم
│   │   ├── context.ts                  # سياق tRPC
│   │   ├── trpc.ts                     # إعدادات tRPC
│   │   ├── oauth.ts                    # المصادقة OAuth
│   │   ├── cookies.ts                  # إدارة الكوكيز
│   │   ├── env.ts                      # متغيرات البيئة
│   │   ├── llm.ts                      # تكامل LLM
│   │   ├── imageGeneration.ts          # توليد الصور
│   │   ├── voiceTranscription.ts       # تحويل الصوت لنص
│   │   ├── dataApi.ts                  # API البيانات
│   │   ├── map.ts                      # تكامل الخريطة
│   │   ├── notification.ts             # الإشعارات
│   │   ├── sdk.ts                      # SDK الخدمات
│   │   ├── vite.ts                     # تكامل Vite
│   │   ├── systemRouter.ts             # روتر النظام
│   │   └── types/
│   │       ├── cookie.d.ts
│   │       └── manusTypes.ts           # أنواع Manus
│   ├── routers.ts                      # روترات tRPC الرئيسية
│   ├── db.ts                           # دوال قاعدة البيانات
│   ├── storage.ts                      # تكامل S3
│   ├── auth.logout.test.ts             # اختبار تسجيل الخروج
│   ├── chat.test.ts                    # اختبار المحادثة
│   ├── images.test.ts                  # اختبار الصور
│   ├── text.test.ts                    # اختبار النصوص
│   └── usage.test.ts                   # اختبار الاستخدام
│
├── 📂 drizzle/                         # قاعدة البيانات
│   ├── schema.ts                       # مخطط الجداول
│   ├── relations.ts                    # العلاقات بين الجداول
│   ├── drizzle.config.ts               # إعدادات Drizzle
│   ├── 📂 migrations/                  # ملفات الترحيل
│   │   ├── 0000_romantic_pepper_potts.sql
│   │   └── 0001_chief_speed_demon.sql
│   └── 📂 meta/                        # بيانات وصفية
│       ├── _journal.json
│       ├── 0000_snapshot.json
│       └── 0001_snapshot.json
│
├── 📂 shared/                          # الكود المشترك
│   └── const.ts                        # الثوابت المشتركة
│
├── 📂 patches/                         # تصحيحات الحزم
│   └── wouter@3.7.1.patch
│
├── 📄 package.json                     # حزم المشروع
├── 📄 pnpm-lock.yaml                   # قفل الحزم
├── 📄 tsconfig.json                    # إعدادات TypeScript
├── 📄 vite.config.ts                   # إعدادات Vite
├── 📄 vitest.config.ts                 # إعدادات Vitest
├── 📄 drizzle.config.ts                # إعدادات Drizzle
├── 📄 components.json                  # إعدادات shadcn/ui
├── 📄 .prettierrc                      # إعدادات Prettier
├── 📄 .prettierignore                  # ملفات Prettier المستثناة
├── 📄 .gitignore                       # ملفات Git المستثناة
│
├── 📄 .env.example                     # مثال متغيرات البيئة
├── 📄 DEPLOYMENT.md                    # دليل النشر العام
├── 📄 README-DEPLOYMENT.md             # دليل النشر التفصيلي
├── 📄 DIGITALOCEAN-MYSQL-SETUP.md      # دليل DigitalOcean الكامل
├── 📄 DIGITALOCEAN-QUICK-START.md      # دليل DigitalOcean السريع
├── 📄 FILE-STRUCTURE.md                # هذا الملف
├── 📄 todo.md                          # قائمة المهام
└── 📄 README.md                        # ملف README الرئيسي
```

---

## 📋 وصف الملفات الرئيسية

### Frontend (client/)

| الملف | الوصف |
|------|-------|
| `App.tsx` | المكون الرئيسي - يحتوي على التوجيه والتخطيط |
| `main.tsx` | نقطة البداية - يقوم بتحميل التطبيق |
| `index.css` | الأنماط العامة والمتغيرات CSS |
| `const.ts` | الثوابت مثل رابط تسجيل الدخول |
| `lib/trpc.ts` | عميل tRPC للاتصال بالخادم |

### Backend (server/)

| الملف | الوصف |
|------|-------|
| `_core/index.ts` | نقطة بداية الخادم - تشغيل Express |
| `routers.ts` | جميع روترات tRPC (API endpoints) |
| `db.ts` | دوال قاعدة البيانات (queries) |
| `storage.ts` | دوال رفع الملفات إلى S3 |
| `_core/llm.ts` | تكامل الذكاء الاصطناعي |

### Database (drizzle/)

| الملف | الوصف |
|------|-------|
| `schema.ts` | تعريف جميع جداول قاعدة البيانات |
| `relations.ts` | العلاقات بين الجداول |
| `migrations/` | ملفات SQL لتطبيق التغييرات |

### Tests (server/*.test.ts)

| الملف | الوصف |
|------|-------|
| `auth.logout.test.ts` | اختبار تسجيل الخروج |
| `chat.test.ts` | اختبار المحادثة |
| `images.test.ts` | اختبار توليد الصور |
| `text.test.ts` | اختبار تحليل النصوص |
| `usage.test.ts` | اختبار تتبع الاستخدام |

---

## 🗂️ جداول قاعدة البيانات

```sql
-- جدول المستخدمين
users (id, openId, name, email, role, subscriptionTier, ...)

-- جداول المحادثة
conversations (id, userId, title, createdAt)
messages (id, conversationId, role, content, createdAt)

-- جداول الصور
generatedImages (id, userId, prompt, imageUrl, createdAt)

-- جداول تحليل النصوص
textAnalyses (id, userId, inputText, outputText, analysisType, ...)

-- جداول الملفات
uploadedFiles (id, userId, filename, fileUrl, mimeType, ...)

-- جداول الاستخدام
usageTracking (id, userId, month, chatMessages, imagesGenerated, ...)

-- جداول الاشتراكات
subscriptions (id, userId, stripeCustomerId, status, ...)
```

---

## 🚀 كيفية تشغيل المشروع

### تثبيت الحزم
```bash
pnpm install
```

### تطبيق المخططات
```bash
pnpm db:push
```

### التطوير المحلي
```bash
pnpm dev
```

### البناء للإنتاج
```bash
pnpm build
```

### تشغيل الإنتاج
```bash
pnpm start
```

### تشغيل الاختبارات
```bash
pnpm test
```

---

## 📝 ملاحظات مهمة

1. **لا تعدّل** ملفات `_core/` إلا إذا كنت تعرف ما تفعل
2. **استخدم** `pnpm` بدلاً من `npm` للحصول على أفضل أداء
3. **احفظ** ملف `.env` في مكان آمن ولا تشاركه
4. **شغّل** `pnpm db:push` بعد أي تغيير على `schema.ts`
5. **اختبر** الكود قبل النشر: `pnpm test`

---

## 🔗 الملفات المرتبطة

- **DEPLOYMENT.md** - دليل النشر العام
- **DIGITALOCEAN-MYSQL-SETUP.md** - دليل DigitalOcean الكامل
- **DIGITALOCEAN-QUICK-START.md** - دليل البدء السريع
- **README-DEPLOYMENT.md** - دليل النشر التفصيلي
- **todo.md** - قائمة المهام والميزات

---

## ✅ قائمة التحقق قبل النشر

- [ ] جميع الملفات موجودة
- [ ] `pnpm install` تم بنجاح
- [ ] `.env` تم إنشاؤه بالمتغيرات الصحيحة
- [ ] `pnpm db:push` تم بنجاح
- [ ] `pnpm test` اجتاز جميع الاختبارات
- [ ] `pnpm build` تم بنجاح
- [ ] `pnpm start` يعمل بدون أخطاء

استمتع بـ خزانتي برو! 🎉
